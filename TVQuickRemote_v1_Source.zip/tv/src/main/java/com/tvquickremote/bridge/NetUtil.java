package com.tvquickremote.bridge;

import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.Enumeration;

public final class NetUtil {
    private NetUtil() { }
    public static String localIp() {
        String fallback = "未连接局域网";
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (java.net.InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress() || a.isLinkLocalAddress()) continue;
                    String ip = a.getHostAddress();
                    if (ni.getName().startsWith("eth") || ni.getName().startsWith("wlan")) return ip;
                    fallback = ip;
                }
            }
        } catch (Exception ignored) { }
        return fallback;
    }
}
