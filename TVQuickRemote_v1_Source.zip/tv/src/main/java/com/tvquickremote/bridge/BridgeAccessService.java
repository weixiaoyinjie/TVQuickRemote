package com.tvquickremote.bridge;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.util.Log;

/** User must explicitly enable this service in the TV Accessibility settings. */
public class BridgeAccessService extends AccessibilityService {
    public static volatile BridgeAccessService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* We do not inspect any UI content. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public boolean openApp(String packageName) {
        try {
            Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(packageName);
            if (i == null) i = getPackageManager().getLaunchIntentForPackage(packageName);
            if (i == null) return false;
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
            return true;
        } catch (Exception e) {
            Log.e("TVQuickBridge", "App launch failed: " + packageName, e);
            return false;
        }
    }
}
