package com.tvquickremote.bridge;

import android.accessibilityservice.AccessibilityService;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/** Paired, LAN-only receiver; no accessibility screen inspection and no internet/cloud traffic. */
public class BridgeService extends Service {
    public static final int PORT = 9842;
    private final AtomicBoolean listening = new AtomicBoolean(false);
    private ExecutorService workers;
    private volatile ServerSocket server;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private int invalidPins = 0;
    private long blockedUntil = 0;
    private static final SecureRandom random = new SecureRandom();

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences("bridge", MODE_PRIVATE);
    }
    private static String newToken() {
        byte[] bytes = new byte[32]; random.nextBytes(bytes);
        return Base64.encodeToString(bytes, Base64.NO_WRAP | Base64.URL_SAFE | Base64.NO_PADDING);
    }
    private static String newPin() { return String.valueOf(10000000 + random.nextInt(90000000)); }
    public static synchronized String pin(Context c) {
        String p = prefs(c).getString("pin", "");
        if (p.isEmpty()) {
            p = newPin();
            prefs(c).edit().putString("pin", p).putString("token", newToken()).apply();
        }
        return p;
    }
    private static synchronized String token(Context c) {
        pin(c);
        return prefs(c).getString("token", "");
    }
    public static synchronized void resetKeys(Context c) {
        prefs(c).edit().putString("pin", newPin()).putString("token", newToken()).commit();
    }

    @Override public void onCreate() {
        super.onCreate();
        workers = Executors.newFixedThreadPool(6);
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        makeForeground();
        if (listening.compareAndSet(false, true)) {
            Thread t = new Thread(this::serve, "TVQuickBridge-Listener");
            t.setDaemon(true);
            t.start();
        }
        return START_STICKY;
    }
    private void makeForeground() {
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("bridge_connection", "TV Quick Bridge", NotificationManager.IMPORTANCE_LOW));
        }
        Intent open = new Intent(this, TvMainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent click = PendingIntent.getActivity(this, 0, open, flags);
        Notification n = new Notification.Builder(this, "bridge_connection")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setContentTitle("TV Quick Bridge 正在接收局域网控制")
                .setContentText("手机可控制电视已安装应用 · 端口 9842")
                .setContentIntent(click)
                .setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(24, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        else startForeground(24, n);
    }

    private void serve() {
        try (ServerSocket s = new ServerSocket()) {
            s.setReuseAddress(true);
            s.bind(new InetSocketAddress(InetAddress.getByName("0.0.0.0"), PORT), 20);
            server = s;
            while (!Thread.currentThread().isInterrupted() && !s.isClosed()) {
                Socket incoming = s.accept();
                incoming.setSoTimeout(5000);
                try { workers.execute(() -> handle(incoming)); }
                catch (Exception e) { try { incoming.close(); } catch (Exception ignored) { } }
            }
        } catch (Exception e) {
            if (listening.get()) Log.e("TVQuickBridge", "LAN server failed", e);
        } finally { server = null; listening.set(false); }
    }

    private void handle(Socket socket) {
        try (Socket s = socket) {
            InputStream in = s.getInputStream();
            String start = readLine(in);
            if (start == null || start.length() > 2048) { reply(s, 400, "application/json", bytes("{\"ok\":false}")); return; }
            String[] parts = start.split(" ");
            if (parts.length < 2 || parts[1].length() > 1500) { reply(s, 400, "application/json", bytes("{\"ok\":false}")); return; }
            String method = parts[0];
            String target = parts[1];
            Map<String,String> headers = new HashMap<>();
            for (int i=0; i<40; i++) {
                String line = readLine(in);
                if (line == null || line.length() == 0) break;
                int colon = line.indexOf(':');
                if (colon > 0) headers.put(line.substring(0, colon).trim().toLowerCase(java.util.Locale.ROOT), line.substring(colon+1).trim());
            }
            String path = target.split("\\?", 2)[0];
            if ("/pair".equals(path) && "POST".equals(method)) {
                synchronized (this) {
                    long now = System.currentTimeMillis();
                    if (now < blockedUntil) { jsonReply(s, 429, result(false, "配对尝试过多，请稍后再试")); return; }
                    String supplied = headers.getOrDefault("x-pair-pin", "");
                    if (!TvMainActivity.pairingVisible) { jsonReply(s, 403, result(false, "请先在电视上打开 TV Quick Bridge 配对页面")); return; }
                    if (!pin(this).equals(supplied)) {
                        invalidPins++;
                        if (invalidPins >= 6) { blockedUntil = now + 60000; invalidPins = 0; }
                        jsonReply(s, 403, result(false, "配对码不正确")); return;
                    }
                    invalidPins=0;
                    JSONObject out = result(true, "配对成功"); out.put("token", token(this)); out.put("port", PORT);
                    jsonReply(s, 200, out);
                }
                return;
            }
            if (!token(this).equals(headers.getOrDefault("x-bridge-token", ""))) {
                jsonReply(s, 401, result(false, "未授权，请重新配对")); return;
            }
            if ("/status".equals(path) && "GET".equals(method)) {
                JSONObject o = result(true, "电视接收端在线");
                o.put("accessibility", BridgeAccessService.instance != null);
                o.put("ip", NetUtil.localIp());
                jsonReply(s, 200, o);
            } else if ("/apps".equals(path) && "GET".equals(method)) {
                JSONObject o = result(true, "应用列表"); o.put("apps", apps()); jsonReply(s, 200, o);
            } else if ("/icon".equals(path) && "GET".equals(method)) {
                String pkg = queryValue(target, "pkg");
                if (!isLaunchable(pkg)) { jsonReply(s, 404, result(false, "未找到应用")); return; }
                try { reply(s, 200, "image/png", appIcon(pkg)); }
                catch (Exception e) { jsonReply(s, 404, result(false, "没有图标")); }
            } else if ("/launch".equals(path) && "POST".equals(method)) {
                String pkg = queryValue(target, "pkg");
                if (!isLaunchable(pkg)) { jsonReply(s, 404, result(false, "该应用不可启动")); return; }
                boolean ok = onMain(() -> {
                    BridgeAccessService svc = BridgeAccessService.instance;
                    return svc != null && svc.openApp(pkg);
                });
                jsonReply(s, ok ? 200 : 409, result(ok, ok ? "已发送应用启动指令" : "无法启动：请在电视上开启本 App 的无障碍控制权限"));
            } else if ("/action".equals(path) && "POST".equals(method)) {
                String name = queryValue(target, "name");
                boolean ok = onMain(() -> performAction(name));
                jsonReply(s, ok ? 200 : 409, result(ok, ok ? "指令已发送" : "指令未执行：检查电视权限、状态或系统限制"));
            } else {
                jsonReply(s, 404, result(false, "未知请求"));
            }
        } catch (Exception e) { Log.d("TVQuickBridge", "Client dropped: " + e.getMessage()); }
    }

    private boolean performAction(String name) {
        BridgeAccessService a = BridgeAccessService.instance;
        switch (name) {
            case "home": return a != null && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
            case "back": return a != null && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
            case "sleep": return a != null && a.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN);
            case "wake":
                try {
                    PowerManager p = (PowerManager)getSystemService(POWER_SERVICE);
                    if (p.isInteractive()) return true;
                    @SuppressWarnings("deprecation") PowerManager.WakeLock wl = p.newWakeLock(
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "tvquickremote:wake");
                    wl.acquire(1500);
                    return true; // A successful call does not guarantee physical TV/HDMI wake.
                } catch (Exception e) { Log.w("TVQuickBridge", "Wake request failed", e); return false; }
            case "volume_up": return volume(AudioManager.ADJUST_RAISE);
            case "volume_down": return volume(AudioManager.ADJUST_LOWER);
            case "mute": return volume(AudioManager.ADJUST_TOGGLE_MUTE);
            case "play_pause":
                try {
                    AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
                    am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
                    am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE));
                    return true;
                } catch (Exception e) { return false; }
            default: return false;
        }
    }
    private boolean volume(int direction) {
        try {
            AudioManager a = (AudioManager)getSystemService(AUDIO_SERVICE);
            a.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
            return true;
        } catch (Exception e) { return false; }
    }
    private interface BooleanWork { boolean run(); }
    private boolean onMain(BooleanWork action) {
        CountDownLatch latch = new CountDownLatch(1);
        final boolean[] result = {false};
        mainHandler.post(() -> { try { result[0] = action.run(); } finally { latch.countDown(); } });
        try { return latch.await(3500, TimeUnit.MILLISECONDS) && result[0]; }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); return false; }
    }

    private LinkedHashMap<String,String> listApps() {
        PackageManager pm = getPackageManager();
        LinkedHashMap<String,String> all = new LinkedHashMap<>();
        for (String category : new String[] {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            Intent i = new Intent(Intent.ACTION_MAIN); i.addCategory(category);
            List<ResolveInfo> matches = pm.queryIntentActivities(i, 0);
            for (ResolveInfo ri : matches) {
                if (ri.activityInfo == null || ri.activityInfo.packageName == null) continue;
                String pkg = ri.activityInfo.packageName;
                if (!all.containsKey(pkg)) {
                    CharSequence label = ri.loadLabel(pm);
                    all.put(pkg, label == null ? pkg : label.toString());
                }
            }
        }
        return all;
    }
    private boolean isLaunchable(String pkg) { return pkg != null && pkg.length() < 256 && listApps().containsKey(pkg); }
    private JSONArray apps() throws Exception {
        ArrayList<Map.Entry<String,String>> sorted = new ArrayList<>(listApps().entrySet());
        Collections.sort(sorted, (a,b) -> a.getValue().compareToIgnoreCase(b.getValue()));
        JSONArray out = new JSONArray();
        for (Map.Entry<String,String> e : sorted) {
            JSONObject o = new JSONObject(); o.put("name",e.getValue()); o.put("package",e.getKey()); out.put(o);
        }
        return out;
    }
    private byte[] appIcon(String pkg) throws Exception {
        Drawable d = getPackageManager().getApplicationIcon(pkg);
        int size = 96;
        Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(b);
        d.setBounds(0,0,size,size); d.draw(canvas);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        b.compress(Bitmap.CompressFormat.PNG, 100, output); b.recycle();
        return output.toByteArray();
    }
    private static String queryValue(String path, String name) throws Exception {
        int qm = path.indexOf('?'); if (qm < 0) return "";
        String[] pairs = path.substring(qm+1).split("&");
        for (String pair : pairs) {
            int eq = pair.indexOf('=');
            if (eq > 0 && pair.substring(0,eq).equals(name)) return URLDecoder.decode(pair.substring(eq+1), "UTF-8");
        }
        return "";
    }
    private static String readLine(InputStream in) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(); int b;
        while ((b=in.read()) != -1 && b != '\n' && bytes.size() < 8192) {
            if (b != '\r') bytes.write(b);
        }
        return b == -1 && bytes.size() == 0 ? null : bytes.toString("UTF-8");
    }
    private static JSONObject result(boolean ok, String message) throws Exception {
        JSONObject o = new JSONObject(); o.put("ok",ok); o.put("message", message); return o;
    }
    private static byte[] bytes(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    private static void jsonReply(Socket s, int status, JSONObject o) throws Exception {
        reply(s, status, "application/json; charset=utf-8", bytes(o.toString()));
    }
    private static void reply(Socket s, int status, String mime, byte[] body) throws Exception {
        String label = status == 200 ? "OK" : status == 401 ? "Unauthorized" : status == 403 ? "Forbidden" : status == 404 ? "Not Found" : status == 409 ? "Conflict" : status == 429 ? "Too Many Requests" : "Bad Request";
        String headers = "HTTP/1.1 " + status + " " + label + "\r\nContent-Type: " + mime + "\r\nContent-Length: " + body.length + "\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        OutputStream out = s.getOutputStream(); out.write(bytes(headers)); out.write(body); out.flush();
    }
    @Override public void onDestroy() {
        listening.set(false);
        try { if (server != null) server.close(); } catch (Exception ignored) { }
        if (workers != null) workers.shutdownNow();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
