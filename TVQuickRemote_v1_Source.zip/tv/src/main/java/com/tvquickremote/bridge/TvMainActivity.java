package com.tvquickremote.bridge;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class TvMainActivity extends Activity {
    public static volatile boolean pairingVisible = false;
    private TextView details;
    private LinearLayout layout;
    private static final int BG = 0xFF0C1220;
    private static final int FG = 0xFFE9F0FA;
    private static final int MUTED = 0xFFACBBD0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        layout = new LinearLayout(this);
        layout.setPadding(dp(52), dp(40), dp(52), dp(50));
        layout.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(layout);
        setContentView(scroll);
        text("TV Quick Bridge", 34, FG);
        text("Google TV 局域网接收端 · v1.0", 19, MUTED);
        details = text("正在检查服务...", 23, FG);
        details.setPadding(0, dp(30), 0, dp(30));
        button("① 开启 TV 控制服务", () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        button("② 启动 / 重启局域网接收服务", this::startBridge);
        button("③ 重置配对（旧手机需要重新配对）", () -> {
            BridgeService.resetKeys(this);
            refresh();
        });
        text("配对步骤", 23, FG);
        text("电视保持在当前页面 → 手机端填写这里的 IP 和 8 位配对码 → 点击连接。\n" +
                "配对结束后可退出该页面，接收服务将尽可能常驻；开机后也会尝试启动。\n" +
                "要在后台打开其他 App，需要先启用上方的无障碍控制服务。\n" +
                "请仅在自己信任的家庭局域网使用，不要把端口映射到互联网。", 17, MUTED);
        startBridge();
    }

    private void startBridge() {
        try {
            Intent i = new Intent(this, BridgeService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) { android.widget.Toast.makeText(this, "启动失败：" + e.getMessage(), android.widget.Toast.LENGTH_LONG).show(); }
        refresh();
    }

    private void refresh() {
        if (details == null) return;
        String ip = NetUtil.localIp();
        String pin = BridgeService.pin(this);
        boolean a11y = BridgeAccessService.instance != null;
        details.setText("电视 IP：" + ip + "\n端口：9842\n8 位配对码：" + pin + "\n控制权限：" + (a11y ? "已开启 ✓" : "未开启（请在无障碍设置中启用）"));
    }

    @Override protected void onResume() { super.onResume(); pairingVisible = true; refresh(); }
    @Override protected void onPause() { pairingVisible = false; super.onPause(); }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(dp(5), 1.03f);
        t.setPadding(0, 0, 0, dp(18));
        layout.addView(t, new LinearLayout.LayoutParams(-1, -2));
        return t;
    }
    private void button(String s, Runnable callback) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(s);
        b.setTextSize(20);
        b.setTextColor(Color.WHITE);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(0xFF2156C5); shape.setCornerRadius(dp(12));
        b.setBackground(shape);
        b.setOnClickListener(v -> callback.run());
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(580), dp(64));
        p.bottomMargin = dp(15);
        layout.addView(b, p);
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
