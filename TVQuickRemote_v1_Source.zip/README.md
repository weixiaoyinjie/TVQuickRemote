# TV Quick Remote v1.0 / 电视快捷遥控

两个原生 Android 应用：

- **TVQuickRemote-Mobile**（手机端）：电视电源（待机 / 尝试唤醒）、主页、返回、音量、播放暂停、全部可启动应用的图标列表、搜索、Kodi / Web Video Caster Receiver / Vimu / YouTube 快捷按钮。
- **TVQuickRemote-TV-Bridge**（Google TV 端）：局域网 HTTP 接收服务、开机自动尝试启动、8 位首次配对码、32 字节随机鉴权密钥、应用图标与启动服务。

这两个 APK 都必须安装；本项目不是依靠 Kodi JSON-RPC，也不用 ADB 或无线调试。

## 一、生成 APK（GitHub Actions）

将本 ZIP **解压后**上传整个文件夹的所有内容到你的 GitHub 仓库根目录，确保 `.github/workflows/build-apks.yml` 也一起上传。

1. 打开仓库的 **Actions** → 左边 **Build TV Quick Remote (Mobile and TV)** → **Run workflow**（或者 push 后自动运行）。
2. 工作流成功后打开最后一次运行，在 **Artifacts** 中下载：
   - `TVQuickRemote-Mobile-APK` → `mobile-debug.apk`
   - `TVQuickRemote-TV-Bridge-APK` → `tv-debug.apk`
3. 手机安装 `mobile-debug.apk`，Google TV Streamer 4K 安装 `tv-debug.apk`。

直接在 Android Studio 中也可构建：Gradle 8.9、JDK 17、Android SDK 35，运行：

```sh
gradle :mobile:assembleDebug :tv:assembleDebug
```

**注意：当前交付包是源码，尚未经过实际 Google TV 和 Galaxy 手机硬件测试。** GitHub Actions 会执行编译并给出真实日志，不能把源码视作已经验证安装成功的 APK。

## 二、首次配置（必做）

### Google TV 端

1. TV 安装打开 **TV Quick Bridge**，允许接收服务持续运行。页面会显示 TV IP、端口 `9842`、8 位配对码。
2. 选择 **① 开启 TV 控制服务**，在 Google TV **设置 → 无障碍** 中找到 **TV Quick Bridge 控制服务**，手工打开。
   - 如果系统提示受限制的设置，请到电视 **设置 → 应用 → TV Quick Bridge → 允许受限制的设置** 中按系统允许的方式开启；部分电视固件可能完全禁用此权限。
   - 服务不读取屏幕内容，只通过官方 `performGlobalAction` 响应主页/返回/锁屏指令，并尝试启动已安装应用。
3. 返回 TV Quick Bridge 页面，确认显示 `控制权限：已开启 ✓`。
4. 为电视在路由器设置 **DHCP 地址保留**，避免 IP 后续改变。

### 手机端

1. 手机和电视连接同一局域网，不能使用访客网络或 AP 客户端隔离模式。
2. 打开 **TV Quick Remote**，输入电视页面上的 IPv4 地址与 8 位配对码，点击 **连接电视**。
3. 配对成功后，手机保存 IP 与随机 Token。电视可离开配对界面，此时接收服务仍会尝试保留在后台。
4. 选择 Kodi 或 Web Video Caster Receiver 等应用快捷方式试运行。

## 三、电源按钮的真实限制

- **进入待机**：使用 Android AccessibilityService 的 `GLOBAL_ACTION_LOCK_SCREEN`，这不等于给外部投影仪或电视彻底断电；具体效果视 Google TV 固件、HDMI-CEC 而定。
- **尝试唤醒**：通过 `PowerManager` 发送短暂亮屏请求。如果 Google TV 的接收进程已被系统停止、网络已休眠、设备已经彻底断电，远程请求根本到不了电视；任何普通第三方 APK 都不能保证通过此方案恢复它。
- Google TV Streamer 的 HDMI-CEC 和电视/投影机自己的开关机属于另一层控制，建议继续用原装遥控器或 Google Home / Google TV 官方虚拟遥控器处理不响应的状态。

## 四、后台运行与系统限制

- 电视端使用 `connectedDevice` 类型前台服务、常驻通知、`BOOT_COMPLETED` 接收器和 `START_STICKY`。Android 系统仍保留强制结束、停用和资源管理的权限；无法承诺“永远后台运行”。
- 电视必须开启无障碍控制权限才能远程打开其他应用。新版 Google TV 可能阻止后台 activity 启动；该情况下手机会收到“指令已发送”，但 App 不一定在屏幕出现。需要根据实机结果继续适配，不能把发送成功当作已成功打开。
- 音量设置可能只作用于 Android 的媒体音量，不能保证控制通过 HDMI-ARC 连接的 Soundbar 音量。

## 五、安全性

- HTTP 服务仅供**可信的家庭 LAN** 使用，端口 **9842**，不要将端口转发到公网。
- 首次配对仅在电视的接收应用处于前台时开放；6 次错误配对码后暂停 60 秒。
- 后续手机请求以 Header 中的随机 Token 鉴权；电视端 **重置配对** 会撤销所有已配对手机的旧 Token。
- 未使用任何云端服务，也没有上传安装应用信息。
- 因为使用明文 HTTP（避免要求配置个人证书），不适合公共 Wi-Fi 或不可信的局域网。

## 六、故障排查

| 现象 | 排查 |
|---|---|
| 手机连接超时 | 检查 TV Bridge 是否打开、IP 是否变化、手机与 TV 是否同一局域网、路由是否启用客户端隔离。 |
| 连接成功但打不开 App | 查看电视的无障碍权限、确认该 App 本身可以从 TV 正常打开，以及固件是否限制后台启动。 |
| 电视重启后无法连接 | 打开一次 TV Bridge 检查接收服务和 IP；系统可能限制开机前台服务。 |
| 待机后无法唤醒 | 说明 Google TV/网络处于更深层休眠或后台服务不可达，请使用 Google TV 原生遥控器。 |
| Web Video Caster 不在快捷区 | 确认电视**接收端**已安装；若应用不出现在列表中，检查它是否有可启动的电视桌面入口。 |

## 技术参数

- 手机包名：`com.tvquickremote.mobile`
- 电视包名：`com.tvquickremote.bridge`
- 接收端 TCP：`9842`，HTTP，JSON；图标 PNG
- Android minSdk：26，targetSdk：35，compileSdk：35
- 语言：Java；无第三方运行时依赖
- 工作流文件：`.github/workflows/build-apks.yml`

## 参考文档

- https://developer.android.com/develop/background-work/services/fgs/service-types
- https://developer.android.com/guide/components/activities/secure-bal
- https://developer.android.com/reference/android/accessibilityservice/AccessibilityService
