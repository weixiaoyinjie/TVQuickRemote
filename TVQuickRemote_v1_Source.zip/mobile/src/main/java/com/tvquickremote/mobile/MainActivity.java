package com.tvquickremote.mobile;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Simple native remote for the separately installed TV Quick Bridge receiver. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0B111E;
    private static final int SURFACE = 0xFF172235;
    private static final int SURFACE2 = 0xFF213451;
    private static final int ACCENT = 0xFF377CFF;
    private static final int WHITE = 0xFFF0F5FC;
    private static final int MUTED = 0xFFA9BCD2;
    private SharedPreferences prefs;
    private final ExecutorService jobs = Executors.newSingleThreadExecutor();
    private final ExecutorService icons = Executors.newFixedThreadPool(4);
    private final LruCache<String, Bitmap> iconCache = new LruCache<>(100);
    private final List<AppEntry> allApps = new ArrayList<>();
    private TextView status, appCount;
    private LinearLayout setupPanel, controlsPanel, favorites;
    private GridLayout appGrid;
    private EditText ipInput, pinInput, searchInput;
    private String connectedIp = "";
    private String token = "";

    private static class AppEntry {
        final String name, pkg;
        AppEntry(String name, String pkg) { this.name=name; this.pkg=pkg; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("mobile_remote", MODE_PRIVATE);
        connectedIp = prefs.getString("ip", "");
        token = prefs.getString("token", "");
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
        if (!connectedIp.isEmpty() && !token.isEmpty()) refresh();
        else showSetup(true);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = column();
        root.setPadding(dp(18), dp(28), dp(18), dp(40));
        scroll.addView(root);
        setContentView(scroll);

        TextView eyebrow = text("LOCAL • PRIVATE • GOOGLE TV", 11, MUTED, true);
        root.addView(eyebrow);
        TextView headline = text("TV Quick Remote", 31, WHITE, true);
        headline.setPadding(0, dp(4), 0, dp(8));
        root.addView(headline);
        status = text("请先连接电视", 14, MUTED, false);
        status.setPadding(0, 0, 0, dp(16));
        root.addView(status);

        setupPanel = column();
        setupPanel.setPadding(dp(15), dp(17), dp(15), dp(17));
        setupPanel.setBackground(shape(SURFACE, 16));
        LinearLayout.LayoutParams sp = lp(-1, -2); sp.bottomMargin = dp(18);
        root.addView(setupPanel, sp);
        setupPanel.addView(text("首次配对", 20, WHITE, true));
        TextView guide = text("电视安装 TV Quick Bridge，打开并查看 IP 和 8 位配对码。手机与电视需连接同一局域网。", 13, MUTED, false);
        guide.setPadding(0, dp(8), 0, dp(12));
        setupPanel.addView(guide);
        ipInput = edit("电视 IP，例如 192.168.1.88");
        ipInput.setSingleLine(true);
        ipInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        ipInput.setText(connectedIp);
        addEdit(setupPanel, ipInput);
        pinInput = edit("电视显示的 8 位配对码");
        pinInput.setSingleLine(true);
        pinInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        addEdit(setupPanel, pinInput);
        TextView connect = action("连接电视", ACCENT);
        setupPanel.addView(connect, lp(-1, dp(50)));
        connect.setOnClickListener(v -> pair());

        controlsPanel = column();
        root.addView(controlsPanel, lp(-1, -2));
        LinearLayout topButtons = new LinearLayout(this);
        topButtons.setGravity(Gravity.CENTER_VERTICAL);
        controlsPanel.addView(topButtons, lp(-1, dp(42)));
        TextView change = text("更换电视 / 重新配对", 12, ACCENT, true);
        change.setGravity(Gravity.CENTER_VERTICAL);
        topButtons.addView(change, new LinearLayout.LayoutParams(0, -1, 1));
        change.setOnClickListener(v -> showSetup(true));
        TextView refresh = text("刷新应用  ↻", 13, WHITE, true);
        refresh.setGravity(Gravity.CENTER_VERTICAL);
        topButtons.addView(refresh);
        refresh.setOnClickListener(v -> refresh());

        controlsPanel.addView(section("电源与基本操作"));
        LinearLayout powerRow = new LinearLayout(this);
        controlsPanel.addView(powerRow, lp(-1, dp(76)));
        addWide(powerRow, "⏻  进入待机", 0xFF9B344B, "sleep");
        addWide(powerRow, "☀  尝试唤醒", SURFACE2, "wake");

        LinearLayout navigationRow = new LinearLayout(this);
        LinearLayout.LayoutParams navlp = lp(-1, dp(56)); navlp.topMargin = dp(8);
        controlsPanel.addView(navigationRow, navlp);
        addWide(navigationRow, "⌂  主页", SURFACE2, "home");
        addWide(navigationRow, "‹  返回", SURFACE2, "back");

        LinearLayout volRow = new LinearLayout(this);
        LinearLayout.LayoutParams vlp = lp(-1, dp(54)); vlp.topMargin = dp(8);
        controlsPanel.addView(volRow, vlp);
        addWide(volRow, "−  音量", SURFACE, "volume_down");
        addWide(volRow, "+  音量", SURFACE, "volume_up");
        addWide(volRow, "♫  暂停", SURFACE, "play_pause");

        controlsPanel.addView(section("快捷启动"));
        favorites = column();
        controlsPanel.addView(favorites, lp(-1, -2));
        controlsPanel.addView(section("电视上的全部应用"));
        searchInput = edit("搜索电视已安装的 App");
        searchInput.setSingleLine(true);
        addEdit(controlsPanel, searchInput);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { drawApps(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        appCount = text("尚未获取应用", 12, MUTED, false);
        controlsPanel.addView(appCount);
        appGrid = new GridLayout(this);
        appGrid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        LinearLayout.LayoutParams gp = lp(-1, -2); gp.topMargin = dp(14);
        controlsPanel.addView(appGrid, gp);
        TextView foot = text("局域网直连 · 无云端账户 · 待机唤醒效果受 Google TV 系统限制", 11, MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(24), 0, 0);
        controlsPanel.addView(foot);
        showSetup(connectedIp.isEmpty() || token.isEmpty());
    }

    private void addWide(LinearLayout parent, String label, int color, String actionName) {
        TextView b = action(label, color);
        b.setTextSize(14);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,-1,1);
        p.rightMargin=dp(5); p.leftMargin=dp(5);
        parent.addView(b,p);
        b.setOnClickListener(v -> sendAction(actionName, label));
    }

    private void pair() {
        String ip = ipInput.getText().toString().trim();
        String pin = pinInput.getText().toString().trim();
        if (!ip.matches("[0-9.]+") || ip.length() < 7 || pin.length() != 8) {
            toast("请填写电视的 IPv4 地址和 8 位配对码"); return;
        }
        status.setText("正在配对 " + ip + "…");
        jobs.execute(() -> {
            try {
                JSONObject obj = call(ip, "", "POST", "/pair", pin);
                if (!obj.optBoolean("ok")) throw new Exception(obj.optString("message", "配对失败"));
                String secret = obj.getString("token");
                prefs.edit().putString("ip",ip).putString("token",secret).apply();
                runOnUiThread(() -> {
                    connectedIp=ip; token=secret;
                    iconCache.evictAll(); pinInput.setText("");
                    showSetup(false);
                    InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(ipInput.getWindowToken(),0);
                    refresh();
                });
            } catch (Exception e) { runOnUiThread(() -> { status.setText("连接失败"); toast(errorMessage(e)); }); }
        });
    }

    private void showSetup(boolean show) {
        setupPanel.setVisibility(show ? View.VISIBLE : View.GONE);
        controlsPanel.setVisibility(show ? View.GONE : View.VISIBLE);
        if (show) status.setText("输入 TV Quick Bridge 显示的 IP 和配对码");
    }

    private void refresh() {
        if (token.isEmpty() || connectedIp.isEmpty()) return;
        status.setText("正在连接电视 " + connectedIp + "…");
        jobs.execute(() -> {
            try {
                JSONObject state = call(connectedIp, token, "GET", "/status", null);
                JSONObject data = call(connectedIp, token, "GET", "/apps", null);
                JSONArray array = data.getJSONArray("apps");
                List<AppEntry> found = new ArrayList<>();
                for (int i=0; i<array.length(); i++) {
                    JSONObject entry = array.getJSONObject(i);
                    found.add(new AppEntry(entry.optString("name"), entry.optString("package")));
                }
                final boolean access = state.optBoolean("accessibility");
                runOnUiThread(() -> {
                    allApps.clear(); allApps.addAll(found);
                    status.setText("● 已连接  " + connectedIp + (access ? "  · 控制权限已开启" : "  · 请开启电视端控制权限"));
                    drawFavorites(); drawApps();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("○ 电视离线 / 无法连接 " + connectedIp);
                    toast(errorMessage(e));
                });
            }
        });
    }

    private void sendAction(String name, String label) {
        jobs.execute(() -> {
            try {
                JSONObject o = call(connectedIp, token, "POST", "/action?name=" + enc(name), null);
                runOnUiThread(() -> toast(o.optString("message", label)));
            } catch (Exception e) { runOnUiThread(() -> toast(errorMessage(e))); }
        });
    }
    private void launchApp(AppEntry app) {
        jobs.execute(() -> {
            try {
                JSONObject o = call(connectedIp, token, "POST", "/launch?pkg=" + enc(app.pkg), null);
                runOnUiThread(() -> toast(app.name + "：" + o.optString("message", "指令已发送")));
            } catch (Exception e) { runOnUiThread(() -> toast(app.name + "：" + errorMessage(e))); }
        });
    }

    private void drawFavorites() {
        favorites.removeAllViews();
        String[][] targets = {
                {"kodi", "Kodi"},
                {"web video caster", "Web Video Caster"},
                {"vimu", "Vimu"},
                {"youtube", "YouTube"}
        };
        int count=0;
        for (String[] t : targets) {
            AppEntry found = null;
            for (AppEntry a : allApps) {
                String name = a.name.toLowerCase(Locale.ROOT);
                if (name.contains(t[0]) || (t[0].equals("web video caster") && a.pkg.contains("instantbits"))) { found=a; break; }
            }
            if (found == null) continue;
            count++;
            AppEntry app=found;
            TextView b = action("▶   " + app.name, SURFACE2);
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            b.setPadding(dp(16),0,dp(12),0);
            LinearLayout.LayoutParams p=lp(-1,dp(48)); p.bottomMargin=dp(8);
            favorites.addView(b,p);
            b.setOnClickListener(v -> launchApp(app));
        }
        if (count==0) favorites.addView(text("未发现 Kodi / Web Video Caster 等常用应用，以下方应用列表为准。", 13, MUTED, false));
    }

    private void drawApps() {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        String query = searchInput == null ? "" : searchInput.getText().toString().toLowerCase(Locale.ROOT).trim();
        List<AppEntry> shown = new ArrayList<>();
        for (AppEntry a : allApps) if (a.name.toLowerCase(Locale.ROOT).contains(query) || a.pkg.toLowerCase(Locale.ROOT).contains(query)) shown.add(a);
        int widthDp = (int)(getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density);
        int cols = widthDp > 680 ? 5 : widthDp > 480 ? 4 : 3;
        appGrid.setColumnCount(cols);
        int tileWidth = dp(Math.max(80,(widthDp - 52) / cols - 8));
        if (appCount != null) appCount.setText("已显示 " + shown.size() + " / " + allApps.size() + " 个应用");
        for (AppEntry a : shown) {
            LinearLayout tile = column();
            tile.setGravity(Gravity.CENTER_HORIZONTAL);
            tile.setPadding(dp(5),dp(11),dp(5),dp(10));
            tile.setBackground(shape(SURFACE, 14));
            ImageView icon = new ImageView(this);
            icon.setImageResource(android.R.drawable.sym_def_app_icon);
            LinearLayout.LayoutParams ilp=lp(dp(52),dp(52));
            ilp.gravity=Gravity.CENTER_HORIZONTAL;
            tile.addView(icon,ilp);
            TextView name = text(a.name, 12, WHITE, false);
            name.setMaxLines(2); name.setGravity(Gravity.CENTER);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams nlp=lp(-1,dp(42)); nlp.topMargin=dp(7);
            tile.addView(name,nlp);
            GridLayout.LayoutParams gridParams = new GridLayout.LayoutParams();
            gridParams.width=tileWidth; gridParams.height=dp(128);
            gridParams.setMargins(dp(4),dp(4),dp(4),dp(4));
            appGrid.addView(tile,gridParams);
            tile.setOnClickListener(v -> launchApp(a));
            loadIcon(icon,a.pkg);
        }
    }

    private void loadIcon(ImageView image, String pkg) {
        Bitmap cached = iconCache.get(pkg);
        image.setTag(pkg);
        if (cached != null) { image.setImageBitmap(cached); return; }
        final String ip = connectedIp; final String key = token;
        if (ip.isEmpty() || key.isEmpty()) return;
        icons.execute(() -> {
            try {
                HttpURLConnection c = connection(ip, "GET", "/icon?pkg=" + enc(pkg), key, null);
                try {
                    if (c.getResponseCode() != 200) return;
                    Bitmap bitmap;
                    try (InputStream stream = c.getInputStream()) {
                        bitmap=BitmapFactory.decodeStream(stream);
                    }
                    if (bitmap == null) return;
                    synchronized(iconCache) { iconCache.put(pkg,bitmap); }
                    runOnUiThread(() -> {
                        if (pkg.equals(image.getTag()) && ip.equals(connectedIp)) image.setImageBitmap(bitmap);
                    });
                } finally { c.disconnect(); }
            } catch (Exception ignored) { }
        });
    }

    private JSONObject call(String ip, String key, String method, String path, String pin) throws Exception {
        HttpURLConnection c = connection(ip, method, path, key, pin);
        try {
            int code = c.getResponseCode();
            InputStream stream = code>=400 ? c.getErrorStream() : c.getInputStream();
            String body="";
            if (stream != null) {
                try (InputStream data=stream; ByteArrayOutputStream buffer=new ByteArrayOutputStream()) {
                    byte[] b = new byte[4096]; int n;
                    while ((n=data.read(b)) >= 0) {
                        buffer.write(b,0,n);
                        if (buffer.size() > 1000000) throw new Exception("响应过大");
                    }
                    body = buffer.toString("UTF-8");
                }
            }
            JSONObject out = new JSONObject(body);
            if (code >=400 || !out.optBoolean("ok",false)) throw new Exception(out.optString("message", "请求失败 (HTTP " + code + ")"));
            return out;
        } finally { c.disconnect(); }
    }
    private HttpURLConnection connection(String ip, String method, String path, String key, String pin) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL("http://" + ip + ":9842" + path).openConnection();
        c.setConnectTimeout(2500); c.setReadTimeout(4500);
        c.setRequestMethod(method); c.setUseCaches(false);
        if (key != null && !key.isEmpty()) c.setRequestProperty("X-Bridge-Token",key);
        if (pin != null) c.setRequestProperty("X-Pair-Pin",pin);
        c.setRequestProperty("Accept", "application/json,image/png");
        return c;
    }
    private static String enc(String s) {
        try { return URLEncoder.encode(s,"UTF-8"); } catch (Exception e) { return s; }
    }

    private TextView section(String s) {
        TextView t=text(s, 19, WHITE, true);
        t.setPadding(0, dp(25), 0, dp(12));
        return t;
    }
    private LinearLayout column() { LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); return c; }
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return v;
    }
    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextColor(WHITE); e.setHintTextColor(MUTED);
        e.setTextSize(15); e.setHint(hint); e.setPadding(dp(12),0,dp(10),0);
        e.setBackground(shape(BG, 10)); return e;
    }
    private void addEdit(LinearLayout parent, EditText e) {
        LinearLayout.LayoutParams p=lp(-1,dp(49)); p.bottomMargin=dp(10);
        parent.addView(e,p);
    }
    private TextView action(String label, int backgroundColor) {
        TextView v = text(label, 15, WHITE, true);
        v.setGravity(Gravity.CENTER);
        v.setBackground(shape(backgroundColor, 12));
        v.setClickable(true); v.setFocusable(true);
        return v;
    }
    private GradientDrawable shape(int color, float corner) {
        GradientDrawable s = new GradientDrawable();
        s.setColor(color); s.setCornerRadius(dp(corner)); return s;
    }
    private LinearLayout.LayoutParams lp(int width, int height) { return new LinearLayout.LayoutParams(width,height); }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density + .5f); }
    private String errorMessage(Exception e) {
        String msg = e.getMessage();
        return msg == null ? "网络连接失败，请检查电视 IP、Wi-Fi 和接收服务" : msg;
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_LONG).show(); }
    @Override protected void onDestroy() { jobs.shutdownNow(); icons.shutdownNow(); super.onDestroy(); }
}
